# R1 V5.1.3 — Báo cáo kỹ thuật nâng G23 và kiểm tra tránh bánh

## 1. Nhận diện hai vấn đề từ ảnh MuJoCo

- Hình hộp màu đỏ phủ lên link robot là sáu BOX proxy không khối lượng và không tham gia contact (nhóm 4). Đã **ẩn trong bản staged** bằng `rgba alpha=0` và `group=5`. Không sửa hash scene nguồn V27, không ẩn mesh thật.
- V5.1.2 nâng thẳng đứng ~120 mm rồi kéo khung về tọa độ lắp; không có chứng chỉ collision clearance với bánh. V5.1.3 thiết kế waypoint tránh các AABB bánh qua hành lang giữa hai bánh.

## 2. Chi tiết hình học

Nguồn: `R1_V27_SCENE.xml` + STL G23, G08, G56 (pin SHA256). Scene V27 dùng **Y là trục đứng**.

| Thông số | Giá trị |
|---|---:|
| Local AABB G23 | 818,269 × 176,377 × 287,0 mm |
| Bánh sau G08 — mặt trên Y world | +32,091 mm |
| Đáy G23 local Y | −88,188 mm |
| TCP→G23 offset demo Y | +150 mm |
| J3 upper bound | +240 mm |
| J3 cần để đặt toàn bộ G23 cao hơn bánh ≥25 mm | +399,638 mm |
| Thiếu hành trình J3 | **+159,638 mm** |
| Chiều cao nâng được lựa chọn | +210 mm so với nguồn |
| J3 max trong trace | +220,678 mm |
| Vị trí X của hành lang giữa hai bánh | +0,066358 m |
| Khoảng hở AABB nhỏ nhất trước pha mate | **36,380 mm** (ngưỡng ≥25 mm) |
| Vận tốc J3 cực đại theo quintic | 22,590 mm/s |
| Thời gian / frame | 65,525 s / 2.622 frame |

Giới hạn J3 vận tốc 25 mm/s chỉ là **ngưỡng nghiên cứu** từ nhánh cũ, không phải giới hạn hãng servo xác nhận. Tăng `-Speed` chỉ làm video MuJoCo Viewer phát nhanh hơn, không phải kiểm định motor.

## 3. Chuỗi pha mới

`REGISTER` → `APPROACH` → `GRASP_MOCK` → `VERTICAL_LIFT_210MM` → `MOVE_OUTSIDE_REAR_WHEEL` → `CROSS_BETWEEN_TWO_WHEELS` → `HOLD_HIGH_VERIFY_CORRIDOR` → `FINAL_MATE_APPROACH_MOCK` → `LOWER_TO_DATUM_MOCK` → `VERIFY_HOLD_MOCK` → `RELEASE_MOCK` → `RETRACT_MOCK` → `DONE_REVIEW`.

- **STRICT_TRANSIT:** từ REGISTER tới HOLD_HIGH. Đã tính toàn bộ frame với AABB G23 và hai bánh từ STL gốc; khoảng hở nhỏ nhất ≥25 mm.
- **UNQUALIFIED_MATING:** từ FINAL_MATE_APPROACH tới DONE. AABB có thể giao nhau vì đây là vùng lắp ghép bánh/swingarm; đây không phải kết luận tam giác mesh xuyên nhau, cũng **không được coi là collision-free**. Cần fixture/pivot/gripper/contact/narrowphase thật.
- MuJoCo chỉ cập nhật `qpos` và `mocap_pos`, gọi `mj_forward`; không gọi `mj_step`; không có vận hành lực/servo thật.

## 4. Cổng nghiệm thu

- **Local unit tests:** 47/47 PASS, gồm bất biến scene/hashes, loại trừ BOX đỏ, hành lang giữa bánh, test sai lệch vị trí bánh bị từ chối, hệ tọa độ và IK giải tích.
- **Native MuJoCo V5.1.3 trên máy phát triển:** CHƯA CHẠY ĐƯỢC trong container (thiếu thư viện `mujoco`), nên native compile/FK của bản này vẫn cần evidence Windows.
- **Frozen V4.8:** chưa thay đổi.
- **Teacher M01/BC/SAC/HIL:** vẫn BLOCKED.

**Điểm quyết định:** Nếu chỉ chấp nhận phương án bắt buộc nhấc G23 *vượt qua đỉnh bánh theo Y* thì J3 với offset kẹp hiện tại không đủ. Cần thay hành trình, cấu trúc gá/robot-base, offset kẹp hoặc thiết kế thao tác theo trục lắp và kiểm chứng thực tế. Bản V5.1.3 cho phép review hành lang vận chuyển, không cấp chứng chỉ seat.
