# G23 geometry-frame comparison — V27 versus later 17-solid mesh export

The source V27 MJCF uses one mesh `G23_gapxe_1.stl`, positioned by the original V27 CAD staging transform. The newer 17-solid STEP-derived export has approximately the same AABB extents, but a different source-frame origin. Direct replacement without a derived `T_old_mesh_to_new_mesh` would shift the assembled component.

Measured with `trimesh` on source data available during this run:

| Metric | Historical V27 STL | Newer 17-STL aggregate |
|---|---:|---:|
| AABB width X | 0.81826949 m | 0.81826949 m |
| AABB width Y | 0.17637673 m | 0.17637680 m |
| AABB width Z | 0.287000 m | 0.287000 m |
| AABB center X | 0.000000 m | 0.04444635 m |
| AABB center Y | 0.000000 m | 0.01004291 m |
| AABB center Z | 0.000000 m | -0.00003509 m |

These are *bounding-box* origin differences and **not** a certified CAD-to-CAD rigid registration. This V5.1 release intentionally retains the **original V27 STL and source transform** so the recorded assembly reference remains consistent. The newer 17-solid export should be used only after formal frame registration from CAD.
