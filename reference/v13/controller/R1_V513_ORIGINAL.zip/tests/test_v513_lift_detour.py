"""V5.1.3 research-scope regression & negative controls.

All clearance assertions are on conservative STL AABBs during NON-MATING
phases. They do NOT assert a physical grasp, wheel-axle insertion or robot
self-collision certificate.
"""
from pathlib import Path
import unittest
import sys
import numpy as np
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

from r1_v51_scene import (SOURCE_WORLD,TARGET_WORLD,RED_ROBOT_REFERENCE_GEOMS,
    ensure_source,make_augmented_scene,sha,JOINTS)
from r1_v51_autoplay import target_sequence, preflight_geometry, analytic_seed
from clearance_review import (geometry_snapshot,public_geometry_snapshot,
    audit_wheel_clearance, separation_aabb, stl_binary_bounds, STL_STANDOFF_M,
    LIFT_M,J3_REVIEW_MAX)

class TestSourceNoTamper(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=ROOT/'source_v27'
        cls.before=sha(cls.source/'R1_V27_SCENE.xml')
        cls.root=ET.fromstring((cls.source/'R1_V27_SCENE.xml').read_bytes())
        cls.rebuilt,_=make_augmented_scene((cls.source/'R1_V27_SCENE.xml').read_bytes())

    def test_v27_original_sha_is_pinned(self):
        self.assertEqual(ensure_source(ROOT)['scene_sha256'],self.before)

    def test_six_red_robot_proxy_geoms_hidden_in_output(self):
        rebuilt={g.get('name'):g for g in self.rebuilt.iter('geom')}
        self.assertEqual(len(RED_ROBOT_REFERENCE_GEOMS),6)
        for name in RED_ROBOT_REFERENCE_GEOMS:
            geom=rebuilt[name]
            self.assertEqual(float(geom.get('rgba').split()[-1]),0.0)
            self.assertEqual(geom.get('group'),'5')
            self.assertEqual(geom.get('contype'),'0')
            self.assertEqual(geom.get('conaffinity'),'0')

    def test_six_original_red_geoms_not_deleted_or_remodeled(self):
        before={g.get('name'):g for g in self.root.iter('geom')}
        after={g.get('name'):g for g in self.rebuilt.iter('geom')}
        for name in RED_ROBOT_REFERENCE_GEOMS:
            self.assertEqual(after[name].get('type'),before[name].get('type'))
            self.assertEqual(after[name].get('size'),before[name].get('size'))
            self.assertEqual(after[name].get('pos'),before[name].get('pos'))

    def test_original_robot_mesh_geoms_still_visible(self):
        rebuilt={g.get('name'):g for g in self.rebuilt.iter('geom')}
        for name in ['R1__v_tower_j1','R1__v_carriage_j3','R1__v_link1_j3',
                     'R1__v_forearm_j2','R1__v_wrist_j4']:
            self.assertEqual(float(rebuilt[name].get('rgba').split()[-1]),1.0)

    def test_original_XML_on_disk_unchanged(self):
        self.assertEqual(sha(self.source/'R1_V27_SCENE.xml'),self.before)

class TestAabbDetour(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geo=geometry_snapshot(ROOT/'source_v27')
        cls.rows=target_sequence(cls.geo)
        cls.clear=audit_wheel_clearance(cls.rows,cls.geo)

    def test_binary_mesh_extents(self):
        a,b=stl_binary_bounds(ROOT/'source_v27/G23_gapxe_1.stl')
        np.testing.assert_allclose(b-a,[.81826949,.17637673,.287],atol=2e-6)

    def test_reading_missing_or_truncated_stl_fail_closed(self):
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as d:
            p=Path(d)/'bad.stl';p.write_bytes(b'abc')
            with self.assertRaisesRegex(ValueError,'STL_TOO_SHORT'):
                stl_binary_bounds(p)

    def test_standoff_positive_before_mating(self):
        self.assertGreaterEqual(self.clear['strict_transit_min_aabb_gap_m'],STL_STANDOFF_M)
        self.assertTrue(self.clear['strict_transit_pass'])

    def test_wheel_corridor_derived_not_hardcoded(self):
        left,right=self.geo['corridor_limits_x']
        center=self.geo['corridor_lane_x']
        self.assertGreater(center,left)
        self.assertLess(center,right)
        self.assertAlmostEqual(center,(left+right)/2,places=12)

    def test_detour_makes_both_wheel_aabbs_separate_when_crossing(self):
        for row in self.rows:
            if row['phase']=='CROSS_BETWEEN_TWO_WHEELS':
                a=(self.geo['module_local_bounds'][0]+row['g23_world'],
                   self.geo['module_local_bounds'][1]+row['g23_world'])
                for b in self.geo['wheel_bounds'].values():
                    gap,_=separation_aabb(a,b)
                    self.assertGreaterEqual(gap,STL_STANDOFF_M)

    def test_lift_raises_world_y_exactly_210mm(self):
        rs=[r for r in self.rows if r['phase']=='VERTICAL_LIFT_210MM']
        self.assertAlmostEqual(rs[-1]['g23_world'][1]-rs[0]['g23_world'][1],LIFT_M,places=10)

    def test_lift_does_not_exceed_J3_research_limit(self):
        v=preflight_geometry()
        self.assertLess(v['q_max']['R1__J3'],J3_REVIEW_MAX)
        self.assertGreater(v['q_max']['R1__J3'],.20)

    def test_provisional_j3_velocity_below_25mm_per_second(self):
        v=preflight_geometry()
        self.assertLess(v['max_analytic_joint_velocity_abs']['R1__J3'],0.025)
        self.assertEqual(v['interpolation'],'QUINTIC_MINIMUM_JERK_ZERO_ENDPOINT_V_A')

    def test_overhead_direct_raise_not_possible_with_current_J3(self):
        a=self.geo['overhead']
        self.assertFalse(a['direct_overhead_achievable_with_existing_grasp_offset'])
        self.assertGreater(a['extra_q3_stroke_needed_m'],.15)
        self.assertGreater(a['q3_required_for_overhead_m'],.39)

    def test_transfer_precedes_unqualified_mate(self):
        phases=list(dict.fromkeys(r['phase'] for r in self.rows))
        self.assertLess(phases.index('CROSS_BETWEEN_TWO_WHEELS'),
                        phases.index('FINAL_MATE_APPROACH_MOCK'))
        self.assertLess(phases.index('FINAL_MATE_APPROACH_MOCK'),
                        phases.index('LOWER_TO_DATUM_MOCK'))

    def test_no_strict_transit_false_pass_by_bad_wheel_position(self):
        bad=dict(self.geo)
        wheel_copy=dict(self.geo['wheel_bounds'])
        rear_name=list(wheel_copy)[0]
        a,b=wheel_copy[rear_name]
        # Make the rear tire AABB cover the transit lane.
        wheel_copy[rear_name]=(a+np.array([.7,0,0]),b+np.array([.7,0,0]))
        bad['wheel_bounds']=wheel_copy
        with self.assertRaisesRegex(ValueError,'NON_MATING_G23_WHEEL_CLEARANCE_BREACH'):
            audit_wheel_clearance(self.rows,bad)

    def test_mating_overlap_is_explicit_not_qualified(self):
        self.assertFalse(self.clear['qualified_loaded_insertion'])
        self.assertFalse(self.clear['qualified_collision_free_whole_cycle'])
        self.assertGreater(self.clear['unqualified_mating_aabb_near_or_overlap_frames'],0)

    def test_all_mate_frames_tagged_as_unqualified(self):
        for row in self.rows:
            if row['phase'] in ('FINAL_MATE_APPROACH_MOCK','LOWER_TO_DATUM_MOCK'):
                self.assertEqual(row['clearance_class'],'UNQUALIFIED_MATING')

    def test_all_early_frames_tagged_as_strict(self):
        for row in self.rows:
            if row['phase'] in ('VERTICAL_LIFT_210MM','MOVE_OUTSIDE_REAR_WHEEL',
                                'CROSS_BETWEEN_TWO_WHEELS'):
                self.assertEqual(row['clearance_class'],'STRICT_TRANSIT')

    def test_end_G23_original_datum(self):
        np.testing.assert_allclose(self.rows[-1]['g23_world'],TARGET_WORLD,atol=1e-12)

    def test_object_immutable_after_release(self):
        for row in self.rows:
            if row['phase'] in ('RELEASE_MOCK','RETRACT_MOCK','DONE_REVIEW'):
                np.testing.assert_allclose(row['g23_world'],TARGET_WORLD,atol=1e-12)

    def test_nonfinite_inputs_rejected_in_geometry(self):
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as d:
            p=Path(d)/'invalid.stl'
            import struct
            p.write_bytes(b'x'*80+struct.pack('<I',1)+struct.pack('<12fH',*(float('nan') if i==4 else 0 for i in range(12)),0))
            with self.assertRaisesRegex(ValueError,'NONFINITE_STL'):
                stl_binary_bounds(p)

if __name__=='__main__':unittest.main()
