"""Regression tests for V5.1.2 Windows Unicode-path native loader.

These tests do not claim native MuJoCo results: they test stage integrity and
use a fake MuJoCo compiler which rejects Unicode XML filenames, matching the
observed failure in the user's Windows project.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

from r1_v51_autoplay import (
    assert_ascii_native_stage, compile_native_model, create_ascii_stage_dir,
    stage_for_native, run,
)
from r1_v51_scene import sha, SOURCE_XML


class TestUnicodeNativeLoad(unittest.TestCase):
    def test_staged_xml_compiles_with_ascii_path_contract(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            output=Path(d)/'Máy tính'/ 'r1_runs' / 'scene_output'
            output.mkdir(parents=True)
            with create_ascii_stage_dir() as ascii_root:
                scene,audit=stage_for_native(ROOT,output,ascii_root)
                self.assertTrue(Path(scene['scene_xml']).exists())
                self.assertTrue(str(scene['scene_xml']).isascii())
                self.assertFalse(str(scene['evidence_xml_path']).isascii())
                self.assertEqual(len(audit['stl_files']),10)
                self.assertEqual(sha(scene['scene_xml']),sha(scene['evidence_xml_path']))
                base=ET.parse(scene['scene_xml']).getroot()
                names=[b.get('name') for b in base.iter('body')]
                for required in (
                    'R1_V15_P1_FRONT_AGV_WHEEL_CHOCK','R1_V15_P4_REAR_AGV_WHEEL_CHOCK',
                    'R1_V15_P2_REAR_CENTER_STAND','R1_V15_P3_FRONT_CENTER_STAND',
                    'module_G23_gapxe_1',
                ):
                    self.assertEqual(names.count(required),1)

    def test_load_path_works_when_old_unicode_output_path_would_fail(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            out=Path(d)/'Máy tính'/'r1_runs'
            out.mkdir(parents=True)
            with create_ascii_stage_dir() as ascii_root:
                scene,audit=stage_for_native(ROOT,out,ascii_root)
                class FakeCompiler:
                    @staticmethod
                    def from_xml_path(p):
                        if not str(p).isascii():
                            raise ValueError('ParseXML: Error opening file')
                        self.assertTrue(Path(p).exists())
                        return 'FAKE_COMPILED_FROM_ASCII_PATH'
                    @staticmethod
                    def from_xml_string(xml,assets):
                        raise AssertionError('fallback should not run')
                fake_mujoco=type('FakeMuJoCo',(),{'MjModel':FakeCompiler})
                with self.assertRaisesRegex(ValueError,'ParseXML: Error opening file'):
                    FakeCompiler.from_xml_path(str(scene['evidence_xml_path']))
                model,attempts=compile_native_model(fake_mujoco,scene['scene_xml'],audit)
                self.assertEqual(model,'FAKE_COMPILED_FROM_ASCII_PATH')
                self.assertEqual([x['status'] for x in attempts],['PASS'])

    def test_fallback_in_memory_compiles_when_ascii_path_fails(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            out=Path(d)/'Đường dẫn Unicode';out.mkdir()
            with create_ascii_stage_dir() as ascii_root:
                scene,audit=stage_for_native(ROOT,out,ascii_root)
                class FakeCompiler:
                    @staticmethod
                    def from_xml_path(p):
                        raise ValueError('ParseXML: Error opening file')
                    @staticmethod
                    def from_xml_string(xml, assets):
                        self.assertIn('<mujoco',xml)
                        self.assertEqual(len(assets),10)
                        self.assertTrue(all(isinstance(v,bytes) and len(v)>80 for v in assets.values()))
                        self.assertIn('G23_gapxe_1.stl',assets)
                        return 'FAKE_COMPILED_IN_MEMORY'
                fake_mujoco=type('FakeMuJoCo',(),{'MjModel':FakeCompiler})
                model,attempts=compile_native_model(fake_mujoco,scene['scene_xml'],audit)
                self.assertEqual(model,'FAKE_COMPILED_IN_MEMORY')
                self.assertEqual([x['status'] for x in attempts],['FAIL','PASS'])

    def test_fails_closed_if_both_native_loaders_fail(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            out=Path(d)/'Máy tính';out.mkdir()
            with create_ascii_stage_dir() as ascii_root:
                scene,audit=stage_for_native(ROOT,out,ascii_root)
                class FakeCompiler:
                    @staticmethod
                    def from_xml_path(p):
                        raise ValueError('BROKEN_XML')
                    @staticmethod
                    def from_xml_string(xml,assets):
                        raise ValueError('BROKEN_ASSETS')
                fake_mujoco=type('FakeMuJoCo',(),{'MjModel':FakeCompiler})
                with self.assertRaisesRegex(RuntimeError,'NATIVE_COMPILE_FAILED_BOTH_ASCII_AND_IN_MEMORY'):
                    compile_native_model(fake_mujoco,scene['scene_xml'],audit)

    def test_unicode_xml_not_accepted_as_native_loader_argument(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            out=Path(d)/'Máy tính';out.mkdir()
            with create_ascii_stage_dir() as ascii_root:
                scene,audit=stage_for_native(ROOT,out,ascii_root)
                with self.assertRaisesRegex(ValueError,'NATIVE_SCENE_PATH_NOT_ASCII'):
                    assert_ascii_native_stage(scene['evidence_xml_path'])

    def test_staged_scene_built_under_new_ascii_root_is_stable(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            hashes=[]
            for i in (1,2):
                out=Path(d)/f'evidence{i}'
                with create_ascii_stage_dir() as ascii_root:
                    scene,audit=stage_for_native(ROOT,out,ascii_root)
                    hashes.append(audit['staged_xml_sha256'])
            self.assertEqual(hashes[0],hashes[1])

    def test_python_static_mode_on_unicode_output_is_valid(self):
        with tempfile.TemporaryDirectory(prefix='r1v512_out_') as d:
            out=Path(d)/'Máy tính'/'r1_runs'
            ret=run(['--package',str(ROOT),'--out',str(out),'--mode','static'])
            self.assertEqual(ret,0)
            gate=json.loads((out/'R1_V51_GATE.json').read_text(encoding='utf-8'))
            self.assertTrue(gate['native_compile_path_audit']['ascii_native_path_verified'])
            self.assertEqual(gate['status'],'SOURCE_AND_XML_RESTORED_NATIVE_COMPILE_PENDING')
            self.assertFalse(gate['mujoco_compiled_new_scene'])
            self.assertEqual(len(list((out/'scene').glob('*.stl'))),10)

if __name__=='__main__':
    unittest.main()
