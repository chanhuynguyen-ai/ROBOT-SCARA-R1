import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from r1_v51_scene import (AGV_STANDS,FIXTURES,G23_NAME,JOINTS,TARGET_WORLD,
                         SOURCE_WORLD,WHEEL_NAMES,assert_original_layout,sha,
                         ensure_source,make_augmented_scene,stage_scene)
from r1_v51_autoplay import (target_sequence,analytic_seed,preflight_geometry,PHI,
                            L1,L2,L3,ROBOT_BASE_WORLD)

class TestRecoveredSource(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old_xml=(ROOT/'source_v27/R1_V27_SCENE.xml').read_bytes()
        cls.original=ET.fromstring(cls.old_xml)
        cls.augmented,cls.layout=make_augmented_scene(cls.old_xml)

    def test_v27_pinned_stage(self):
        man=ensure_source(ROOT)
        self.assertEqual(man['scene_sha256'],'240ea346c162111a8846e7f66932352ca73293c5edc035d33de4b09896800de9')
        self.assertTrue(man['native_mujoco_compiled'])
        self.assertFalse(man['Teacher_allowed'])

    def test_two_original_agvs_present(self):
        names=[b.get('name') for b in self.augmented.iter('body')]
        for name in AGV_STANDS:self.assertEqual(names.count(name),1)

    def test_two_original_fixed_center_stands_present(self):
        names=[b.get('name') for b in self.augmented.iter('body')]
        for name in FIXTURES:self.assertEqual(names.count(name),1)

    def test_both_original_cad_wheels_present(self):
        names=[b.get('name') for b in self.augmented.iter('body')]
        for name in WHEEL_NAMES:self.assertEqual(names.count(name),1)

    def test_original_mount_names_not_guessed(self):
        for name in AGV_STANDS+FIXTURES+WHEEL_NAMES:
            a=next(b for b in self.original.iter('body') if b.get('name')==name)
            b=next(b for b in self.augmented.iter('body') if b.get('name')==name)
            self.assertEqual(ET.tostring(a),ET.tostring(b),name)

    def test_source_G23_pose_restored(self):
        b=next(b for b in self.augmented.iter('body') if b.get('name')==G23_NAME)
        self.assertEqual(tuple(map(float,b.get('pos').split())),TARGET_WORLD)
        self.assertEqual(b.get('mocap'),'true')

    def test_original_frozen_4joints_preserved(self):
        j=[x.get('name') for x in self.augmented.iter('joint')]
        self.assertEqual(set(j),set(JOINTS))
        self.assertEqual(len(j),4)

    def test_cad_G29_reference_and_feeder_are_annotated(self):
        names=[b.get('name') for b in self.augmented.iter('body')]
        self.assertIn('v51_g29_rear_frame_reference_body',names)
        self.assertIn('v51_g23_feeder_PROXY',names)
        self.assertIn('v51_original_g23_assembled_reference',
                      [s.get('name') for s in self.augmented.iter('site')])

    def test_all_added_geoms_are_noncolliding(self):
        for g in self.augmented.iter('geom'):
            if g.get('name','').startswith('v51_'):
                self.assertEqual(g.get('contype'),'0')
                self.assertEqual(g.get('conaffinity'),'0')

    def test_staging_copies_original_xml_unchanged(self):
        before=sha(ROOT/'source_v27/R1_V27_SCENE.xml')
        with tempfile.TemporaryDirectory() as d:
            item=stage_scene(ROOT,d)
            self.assertTrue(Path(item['scene_xml']).exists())
            self.assertEqual(len(list(Path(d).glob('*.stl'))),10)
            self.assertEqual(item['source_xml_sha256'],before)
        self.assertEqual(sha(ROOT/'source_v27/R1_V27_SCENE.xml'),before)

class TestTaskLogic(unittest.TestCase):
    def test_kinematic_frames_both_ends(self):
        rows=target_sequence()
        self.assertEqual(len(rows),2622)
        self.assertEqual(rows[0]['object_state'],'SOURCE')
        np.testing.assert_allclose(rows[0]['g23_world'],SOURCE_WORLD,atol=1e-12)
        np.testing.assert_allclose(rows[-1]['g23_world'],TARGET_WORLD,atol=1e-12)

    def test_11_stages_and_all_expected(self):
        names=list(dict.fromkeys(r['phase'] for r in target_sequence()))
        for key in ('GRASP_MOCK','VERTICAL_LIFT_210MM','MOVE_OUTSIDE_REAR_WHEEL','CROSS_BETWEEN_TWO_WHEELS','FINAL_MATE_APPROACH_MOCK','LOWER_TO_DATUM_MOCK','RELEASE_MOCK','RETRACT_MOCK'):
            self.assertIn(key,names)
        self.assertEqual(len(names),13)

    def test_grip_does_not_move_module_until_lift(self):
        rows=target_sequence()
        for row in rows:
            if row['phase'] in ('REGISTER','APPROACH','GRASP_MOCK'):
                np.testing.assert_allclose(row['g23_world'],SOURCE_WORLD,atol=1e-12)

    def test_module_tracks_TCP_along_visual_attachment(self):
        rows=target_sequence()
        for row in rows:
            if row['object_state']=='ATTACH':
                np.testing.assert_allclose(row['g23_world'],row['tcp_target']-np.asarray((0.,.15,0.)),atol=1e-12)

    def test_after_release_G23_stays_seated(self):
        for row in target_sequence():
            if row['phase'] in ('RELEASE_MOCK','RETRACT_MOCK','DONE_REVIEW'):
                np.testing.assert_allclose(row['g23_world'],TARGET_WORLD,atol=1e-12)

    def test_joint_limits_kinematic_seed_no_overruns(self):
        r=preflight_geometry()
        self.assertEqual(r['stage_count'],13)
        self.assertLess(r['q_max']['R1__J2'],1.74533)
        self.assertGreater(r['q_min']['R1__J3'],-.04)
        self.assertLess(r['q_max']['R1__J3'],.24)

    def test_expected_tcp_forward_planar_formula(self):
        # Apply analytically derived geometry before native fine registration.
        for row in target_sequence()[::17]:
            q=analytic_seed(row['tcp_target'])
            q1,q3,q2,q4=q
            locx=L1*np.cos(q1)+L2*np.cos(q1+q2)+L3*np.cos(q1+q2+q4)
            locy=L1*np.sin(q1)+L2*np.sin(q1+q2)+L3*np.sin(q1+q2+q4)
            xyz=np.array([ROBOT_BASE_WORLD[0]+locx,ROBOT_BASE_WORLD[1]+q3,ROBOT_BASE_WORLD[2]-locy])
            np.testing.assert_allclose(xyz,row['tcp_target'],atol=5e-6)

    def test_no_teacher_or_hardware_approval(self):
        result=preflight_geometry()
        self.assertEqual(result['real_software_teacher_episodes'],0)
        self.assertFalse(result['physical_grasp_validated'])

if __name__=='__main__': unittest.main()
