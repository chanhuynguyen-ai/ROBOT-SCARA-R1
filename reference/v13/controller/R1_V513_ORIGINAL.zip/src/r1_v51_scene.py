"""Restore original, hash-pinned V27 R1 M01 scene and add visual inspection only.

Source: r1_runs.zip -> R1_V27_STAGED_SKILLS... / 01_M01_GAPXE_REFERENCE.
The two AGVs, two original P2/P3 stands, wheels and robot are NEVER rebuilt
as guessed new coordinates: they are retained byte-for-byte from the source XML.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

SOURCE_XML='R1_V27_SCENE.xml'
G23_NAME='module_G23_gapxe_1'
TCP_SITE='R1__tcp'
JOINTS=('R1__J1','R1__J3','R1__J2','R1__J4')
WHEEL_NAMES=('module_G08_banhxe_1','module_G56_banhtruoc_SEPARATE_FROM_FRONT_STEERING')
AGV_STANDS=('R1_V15_P1_FRONT_AGV_WHEEL_CHOCK','R1_V15_P4_REAR_AGV_WHEEL_CHOCK')
FIXTURES=('R1_V15_P2_REAR_CENTER_STAND','R1_V15_P3_FRONT_CENTER_STAND')
TARGET_WORLD=(-0.302850,-0.243680,0.0)
SOURCE_WORLD=(-0.45,-0.245,0.37) # G23 feeder proxy; NOT original measured fixture
GRASP_WORLD_OFFSET=(0,0.15,0) # not a CAD-approved TCP offset
SOURCE_ROOT='R1_V27_STAGED_SKILLS_20261018T115920833Z_574a790b'
# Six red translucent robot BOX reference proxies from V27, not actual CAD meshes.
# Source XML remains unchanged. Review scene makes them invisible, preserving type and IDs.
RED_ROBOT_REFERENCE_GEOMS=(
 'R1__R1V22_SOURCE_WORLD_001',
 'R1__c_tower_guard', 'R1__c_z_carriage', 'R1__c_link_1',
 'R1__c_link_2', 'R1__c_wrist',
)


def sha(path):
    d=hashlib.sha256()
    with Path(path).open('rb') as f:
        for buf in iter(lambda:f.read(1024*1024),b''):
            d.update(buf)
    return d.hexdigest()


def ensure_source(package_root):
    root=Path(package_root)
    base=root/'source_v27'
    manifest=json.loads((base/'R1_V27_STAGE_MANIFEST.json').read_text(encoding='utf-8'))
    assert manifest['stage_id']=='01_M01_GAPXE_REFERENCE'
    assert manifest['scene_sha256']==sha(base/SOURCE_XML),'SOURCE_V27_XML_CHANGED'
    assert len(manifest['mesh_sha256'])==9
    for name, expected in manifest['mesh_sha256'].items():
        assert sha(base/name)==expected,'SOURCE_MESH_CHANGED_'+name
    extra=json.loads((root/'reference/ARCHIVE_PROVENANCE.json').read_text(encoding='utf-8'))
    for name,expected in extra['additional_visual_CAD'].items():
        assert sha(base/name)==expected,'ADDITIONAL_CAD_MESH_CHANGED_'+name
    return manifest


def original_worldbody(root):
    return root.find('worldbody')


def assert_original_layout(mjcf_root):
    wb=original_worldbody(mjcf_root)
    assert wb is not None
    names={b.get('name'):b for b in wb.iter('body')}
    for name in (*AGV_STANDS,*FIXTURES,*WHEEL_NAMES,G23_NAME):
        assert name in names,'ORIGINAL_LAYOUT_MISSING_'+name
    joints={x.get('name'):x for x in wb.iter('joint')}
    for name in JOINTS:
        assert name in joints,'ROBOT_JOINT_MISSING_'+name
    sites={s.get('name'):s for s in wb.iter('site')}
    for name in ('R1_V15_P2_REAR_DATUM_REVIEW_ONLY','R1_V15_P3_FRONT_DATUM_REVIEW_ONLY',TCP_SITE):
        assert name in sites,'SOURCE_DATUM_OR_TCP_MISSING_'+name
    b=names[G23_NAME]
    assert b.get('mocap')=='true'
    target=[float(v) for v in b.get('pos').split()]
    assert max(abs(x-y) for x,y in zip(target,TARGET_WORLD))<1e-7,'ORIGINAL_G23_TARGET_MOVED'
    return {'wheel_bodies':list(WHEEL_NAMES), 'agv_bodies':list(AGV_STANDS),
            'stand_bodies':list(FIXTURES), 'original_g23_target_m':target,
            'tcp_site':TCP_SITE, 'joints':list(JOINTS)}


def add_proxy_geom(body, name, size, pos, rgba):
    return ET.SubElement(body,'geom',{
        'name':name,'type':'box',
        'size':' '.join(str(v) for v in size), 'pos':' '.join(str(v) for v in pos),
        'rgba':rgba,'group':'4','contype':'0','conaffinity':'0','mass':'0'})


def make_augmented_scene(xml_bytes):
    root=ET.fromstring(xml_bytes)
    confirmed=assert_original_layout(root)
    # Visual-only cleanup: hide six transparent red BOX proxies rendered over robot.
    # They have contype=conaffinity=0 and zero mass in V27. Real robot CAD remains visible.
    all_geoms={geom.get('name'):geom for geom in root.iter('geom')}
    for name in RED_ROBOT_REFERENCE_GEOMS:
        geom=all_geoms.get(name)
        if geom is None:
            raise ValueError('V27_RED_PROXY_MISSING_'+name)
        if geom.get('type')!='box' or geom.get('contype')!='0' or geom.get('conaffinity')!='0' or geom.get('mass')!='0':
            raise ValueError('REFUSE_HIDE_NONVISUAL_OR_PHYSICAL_GEOM_'+name)
        geom.set('rgba','0.94 0.25 0.12 0')
        geom.set('group','5')
    confirmed['red_robot_visual_proxy_hidden']=list(RED_ROBOT_REFERENCE_GEOMS)
    wb=original_worldbody(root)
    assets=root.find('asset')
    assert assets is not None
    # G29 CAD is a REAR FRAME REFERENCE extracted from old full CAD snapshot,
    # not an approved external chassis CAD.
    ET.SubElement(assets,'mesh',{'name':'v51_g29_rear_frame_reference',
                                 'file':'G29_khunngxe_sau_moi_1.stl'})
    frame=ET.SubElement(wb,'body',{'name':'v51_g29_rear_frame_reference_body',
                                  'pos':'-0.220333 -0.0239273 -0.000000511'})
    ET.SubElement(frame,'geom',{'name':'v51_g29_rear_frame_reference',
         'type':'mesh','mesh':'v51_g29_rear_frame_reference','contype':'0',
         'conaffinity':'0','group':'4','rgba':'0.55 0.72 0.97 0.27','mass':'0'})
    # Add visual-only feeder, separately from real V27 AGV + stands.
    feeder=ET.SubElement(wb,'body',{'name':'v51_g23_feeder_PROXY'})
    add_proxy_geom(feeder,'v51_feeder_platform',(0.36,0.02,0.22),(-0.45,-0.45,0.37),'0.4 0.42 0.47 0.8')
    add_proxy_geom(feeder,'v51_feeder_column',(0.035,0.09,0.035),(-0.45,-0.55,0.37),'0.35 0.43 0.50 0.9')
    ET.SubElement(feeder,'site',{'name':'v51_feeder_unapproved_position',
          'pos':' '.join(map(str,SOURCE_WORLD)),'size':'0.018','group':'4',
          'rgba':'0.96 0.58 0.12 1'})
    ET.SubElement(wb,'site',{'name':'v51_original_g23_assembled_reference',
          'pos':' '.join(map(str,TARGET_WORLD)),'size':'0.02','group':'4',
          'rgba':'0.20 1.0 0.18 1'})
    # Sites visualise gripper jaw state but exert NO force or contact.
    tcp=next(b for b in wb.iter('body') if b.get('name')=='R1__tcp_body_no_gripper')
    for side in (-1,1):
        ET.SubElement(tcp,'site',{'name':'v51_mock_jaw_'+('left' if side<0 else 'right'),
            'type':'box','pos':f'0 {side*0.115} -0.055',
            'size':'0.075 0.010 0.045','group':'4','rgba':'1 0.54 0.16 0.70'})
    return root,confirmed


def stage_scene(package_root, out_dir):
    package_root=Path(package_root)
    man=ensure_source(package_root)
    source=package_root/'source_v27'
    out_dir=Path(out_dir)
    out_dir.mkdir(parents=True,exist_ok=True)
    doc,layout=make_augmented_scene((source/SOURCE_XML).read_bytes())
    target=out_dir/'R1_V51_RESTORED_AGV_P2_P3_G23_AUTO.xml'
    ET.ElementTree(doc).write(target,encoding='utf-8',xml_declaration=True)
    required=sorted({*man['mesh_sha256'].keys(),'G29_khunngxe_sau_moi_1.stl'})
    for fn in required:
        shutil.copy2(source/fn,out_dir/fn)
    return {'source_xml_sha256':man['scene_sha256'],
        'scene_xml':str(target),'scene_sha256':sha(target),
        'required_mesh_count':len(required), 'layout_verified':layout,
        'source_mesh_sha256':dict(man['mesh_sha256']),
        'target_from_original_CAD_reference':True,
        'R1_V48_frozen_modified':False,
        'red_box_robot_proxies_hidden':list(RED_ROBOT_REFERENCE_GEOMS),
        'all_visual_only_assembly':True}
