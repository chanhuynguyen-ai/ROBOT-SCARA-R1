"""Conservative AABB geometry audit for R1 V5.1.3 review-only wheel detour.

- Uses original V27 STL *bytes* and original V27 body world positions.
- Checks cargo-to-wheel separation during NON-MATING travel. AABB clearance is
  conservative when positive; overlap is only a *possible* collision.
- Once approaching the actual wheel/chassis mating pose, collision check is
  ALWAYS unqualified: never turn AABB overlap into an approved insertion.
- Demonstrates why an OVER-THE-WHEEL raise is outside pinned J3 stroke.
"""
from __future__ import annotations
import math
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
import numpy as np

from r1_v51_scene import SOURCE_WORLD, TARGET_WORLD, GRASP_WORLD_OFFSET

WHEEL_MESHES = (
    ('module_G08_banhxe_1','G08_banhxe_1.stl'),
    ('module_G56_banhtruoc_SEPARATE_FROM_FRONT_STEERING','G56_banhtruoc_SEPARATE_FROM_FRONT_STEERING.stl'),
)
MODULE_MESH = 'G23_gapxe_1.stl'
STL_STANDOFF_M = .025
J3_REVIEW_MAX = .24
BASE_WORLD_Y = -.104358
LIFT_M = .21


def stl_binary_bounds(path):
    path = Path(path)
    raw = path.read_bytes()
    if len(raw) < 84:
        raise ValueError('STL_TOO_SHORT:' + str(path))
    n = struct.unpack_from('<I', raw, 80)[0]
    if n == 0 or len(raw) != 84 + 50 * n:
        raise ValueError('REQUIRES_BINARY_STL:' + str(path))
    dtype = np.dtype([('normal', '<f4', (3,)),('v', '<f4', (3,3)),('attr','<u2')])
    tris = np.frombuffer(raw, dtype=dtype, count=n, offset=84)
    pts = np.asarray(tris['v'],dtype=np.float64).reshape(-1,3)
    if not np.all(np.isfinite(pts)):
        raise ValueError('NONFINITE_STL:'+str(path))
    return np.min(pts,axis=0), np.max(pts,axis=0)


def bounds_world(bounds,body_pos):
    offs=np.asarray(body_pos,dtype=float)
    return np.asarray(bounds[0])+offs,np.asarray(bounds[1])+offs


def separation_aabb(a,b):
    """Signed per-axis gaps. Positive on at least one axis => boxes separated."""
    amin,amax = a; bmin,bmax = b
    axis_gap = np.maximum(bmin-amax,amin-bmax)
    return float(np.max(axis_gap)), np.asarray(axis_gap,dtype=float)


def geometry_snapshot(source_root):
    source=Path(source_root)
    root=ET.parse(source/'R1_V27_SCENE.xml').getroot()
    bodies={b.get('name'):b for b in root.iter('body')}
    module=stl_binary_bounds(source/MODULE_MESH)
    if any(not np.isfinite(float(v)) for v in [*module[0],*module[1]]):
        raise ValueError('INVALID_MODULE_BOUNDS')
    wheels={}
    for b,mesh in WHEEL_MESHES:
        body=bodies[b]
        if body.get('quat') not in (None,'1 0 0 0'):
            raise ValueError('WHEEL_BODY_ROTATION_UNSUPPORTED_FOR_AABB_'+b)
        center=np.fromstring(body.get('pos'),sep=' ')
        local=stl_binary_bounds(source/mesh)
        wheels[b]=bounds_world(local,center)
    rear=wheels[WHEEL_MESHES[0][0]]
    front=wheels[WHEEL_MESHES[1][0]]
    # Two wheels have an X-axis gap; choose a center corridor that guarantees at
    # least 25mm AABB gap for the full G23 mesh against both wheel boxes.
    lane_left=rear[1][0]-module[0][0]+STL_STANDOFF_M
    lane_right=front[0][0]-module[1][0]-STL_STANDOFF_M
    if lane_right < lane_left:
        raise ValueError('NO_WHEEL_GAP_CORRIDOR_FOR_G23_WITH_REQUIRED_STANDOFF')
    lane_x=(lane_left+lane_right)/2.
    source=np.asarray(SOURCE_WORLD)
    z_source_rear_clear=(source[2]+module[0][2])-rear[1][2]
    if z_source_rear_clear < STL_STANDOFF_M:
        raise ValueError('FEEDER_Z_NOT_CLEAR_OF_REAR_WHEEL_AABB')
    # Physical overhead gate with the existing J3 slider limit and old TCP->G23
    # mock offset. Direct overhead requires positive Y separation over tire.
    rear_top=float(rear[1][1])
    needed_center_y=rear_top+STL_STANDOFF_M-float(module[0][1])
    needed_tcp_y=needed_center_y+float(GRASP_WORLD_OFFSET[1])
    needed_q3=needed_tcp_y-BASE_WORLD_Y
    max_center_y=BASE_WORLD_Y+J3_REVIEW_MAX-float(GRASP_WORLD_OFFSET[1])
    overhead={
        'desired_min_standoff_m':STL_STANDOFF_M,
        'rear_wheel_world_y_top_m':rear_top,
        'g23_local_bottom_y_m':float(module[0][1]),
        'q3_required_for_overhead_m':float(needed_q3),
        'q3_declared_upper_m':J3_REVIEW_MAX,
        'extra_q3_stroke_needed_m':float(max(0,needed_q3-J3_REVIEW_MAX)),
        'direct_overhead_achievable_with_existing_grasp_offset': bool(needed_q3<=J3_REVIEW_MAX),
        'max_reachable_g23_center_y_m':float(max_center_y),
        'chosen_visual_lift_m':LIFT_M,
    }
    if overhead['direct_overhead_achievable_with_existing_grasp_offset']:
        raise ValueError('V513_REVIEW_ASSUMPTION_STALE_RECALIBRATE_BYPASS_REQUIRED')
    if source[1]+GRASP_WORLD_OFFSET[1]+LIFT_M-BASE_WORLD_Y > J3_REVIEW_MAX-.01:
        raise ValueError('LIFT_WOULD_EXCEED_RESEARCH_J3_WITH_SAFETY_MARGIN')
    return {'module_local_bounds':module,'wheel_bounds':wheels,'corridor_lane_x':float(lane_x),
            'corridor_limits_x':[float(lane_left),float(lane_right)],
            'source_z_rear_standoff_m':float(z_source_rear_clear),
            'overhead':overhead}


def audit_wheel_clearance(rows,geo):
    raw=[];minimum=float('inf');worst=None
    module=geo['module_local_bounds']
    # Phases allowed to have broadphase overlap with mating wheel are explicitly
    # NOT passed as collision-safe: separately recorded unqualified mating zone.
    unqualified=[]
    for r in rows:
        g23=bounds_world(module,r['g23_world'])
        readings={}
        for name,bbox in geo['wheel_bounds'].items():
            sep,axis=separation_aabb(g23,bbox)
            readings[name]=sep
            if r['clearance_class']=='STRICT_TRANSIT':
                if sep<minimum:minimum=sep;worst=(r['index'],r['phase'],name)
                if sep < STL_STANDOFF_M-1e-6:
                    raise ValueError(f'NON_MATING_G23_WHEEL_CLEARANCE_BREACH frame={r["index"]} phase={r["phase"]} wheel={name} gap={sep:.6f}m')
            elif sep<STL_STANDOFF_M:
                unqualified.append({'frame':r['index'],'phase':r['phase'],
                                    'wheel':name,'signed_aabb_gap_m':round(sep,6)})
        raw.append({'frame':r['index'],'phase':r['phase'],'min_wheel_aabb_gap_m':min(readings.values()),
                    'clearance_class':r['clearance_class']})
    if minimum==float('inf'):
        raise ValueError('NO_STRICT_TRANSIT_ROWS')
    return {'strict_transit_min_aabb_gap_m':float(minimum),
            'strict_transit_worst_case':list(worst),
            'required_standoff_m':STL_STANDOFF_M,
            'strict_transit_pass':True,
            'unqualified_mating_aabb_near_or_overlap_frames':len(unqualified),
            'unqualified_mating_examples':unqualified[:8],
            'qualified_loaded_insertion':False,
            'qualified_collision_free_whole_cycle':False,
            'method':'ORIGINAL_CAD_BINARY_STL_WORLD_AABB_REVIEW_ONLY_NOT_NARROWPHASE',
            'per_frame':raw}


def public_geometry_snapshot(geo):
    return {
        'stl_standoff_m':STL_STANDOFF_M,
        'corridor_center_x_m':geo['corridor_lane_x'],
        'corridor_center_allowed_band_x_m':geo['corridor_limits_x'],
        'original_feeder_z_clearance_from_rear_aabb_m':geo['source_z_rear_standoff_m'],
        'g23_local_min_xyz_m':geo['module_local_bounds'][0].tolist(),
        'g23_local_max_xyz_m':geo['module_local_bounds'][1].tolist(),
        'wheels_world_aabbs_m':{name:{'min':v[0].tolist(),'max':v[1].tolist()} for name,v in geo['wheel_bounds'].items()},
        'direct_overhead_feasibility':geo['overhead'],
    }
