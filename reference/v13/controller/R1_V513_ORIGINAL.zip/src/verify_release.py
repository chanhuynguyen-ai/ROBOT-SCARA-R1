#!/usr/bin/env python3
"""Byte-for-byte SHA256 validation for the R1 V5.1 standalone package."""
import hashlib,json,sys
from pathlib import Path

def check(package):
    package=Path(package).resolve()
    data=json.loads((package/'PACKAGE_SHA256_MANIFEST.json').read_text(encoding='utf-8'))
    if data.get('schema')!='R1_V51_SHA256_MANIFEST_V1':raise ValueError('MANIFEST_SCHEMA_MISMATCH')
    if not isinstance(data.get('files'),dict):raise ValueError('MANIFEST_FILES_MISSING')
    expected=data['files'];actual_files={str(p.relative_to(package)).replace('\\','/') for p in package.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.name!='PACKAGE_SHA256_MANIFEST.json'}
    if set(expected)!=actual_files:
        raise ValueError(f'PACKAGE_FILE_LIST_MISMATCH:{sorted(set(expected)^actual_files)}')
    for name,digest in expected.items():
        p=package/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
            raise ValueError('PACKAGE_SHA_MISMATCH:'+name)
    print(f'R1 V5.1.3 PACKAGE SHA256 VERIFIED: {len(expected)} files')
    return True

if __name__=='__main__':
    try: check(sys.argv[1])
    except Exception as e:
        print('BLOCKED:',e,file=sys.stderr)
        sys.exit(2)
