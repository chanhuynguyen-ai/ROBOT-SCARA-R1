#!/usr/bin/env python3
"""Real native MuJoCo *kinematic* review of the restored V27 SCARA cell.

The source is the original V27 compiled research MJCF recovered from r1_runs.zip:
- historical SCARA robot meshes + articulation
- 2 existing AGVs with rear/front wheel CAD previews
- 2 existing center stands P2, P3
- G23 CAD reference geometry

The program runs a full automatic visual task sequence, without Tk controls:
APPROACH -> PICK (visual attach) -> LIFT -> TRANSFER -> ALIGN -> SEAT ->
RELEASE -> RETRACT. The MuJoCo model is used for 4DOF FK/IK and visualization.
It does NOT create a real gripper, contact/load physics, signed fixture mating,
teacher demonstrations or real robot commands. No mj_step, ever.
"""
from __future__ import annotations

import argparse
import bisect
import csv
import hashlib
import json
import os
import shutil
import tempfile
import xml.etree.ElementTree as ET
import math
from pathlib import Path
import sys
import time
import traceback
from datetime import datetime, timezone

import numpy as np
from r1_v51_scene import (SOURCE_WORLD,TARGET_WORLD,GRASP_WORLD_OFFSET,JOINTS,
                          WHEEL_NAMES,AGV_STANDS,FIXTURES,TCP_SITE,G23_NAME,
                          ensure_source,stage_scene,sha)
from clearance_review import (geometry_snapshot,public_geometry_snapshot,
                              audit_wheel_clearance,LIFT_M,STL_STANDOFF_M)

FPS=40
# Original V27 mount transform, not an independently calibrated world frame.
ROBOT_BASE_WORLD=np.array([0.0731083,-0.104358,1.35],dtype=float)
L1=0.82301
L2=0.49750
L3=0.30000
PHI=2.90 # constant wrist direction about local vertical Z (world Y)


def smooth(u):
    u=max(0.,min(1.,float(u)))
    return u*u*u*(10. + u*(-15. + 6.*u))  # quintic min-jerk segment


def vector(x):
    return np.asarray(x,dtype=np.float64)


def target_sequence(geometry=None):
    """Detour/lift choreography while preserving V27 source and assembly datum.

    Vertical axis in the legacy V27 world is Y (not Z). The old TCP-to-G23
    visual offset is +0.15m Y. Raising the tool 0.21m uses J3 but DOES NOT
    physically clear above the entire tire envelope. Instead, plan a detour
    through the X-axis gap between both original wheel AABBs.

    STRICT_TRANSIT phases are guaranteed >=25mm apart from both tire AABBs.
    FINAL_MATE_APPROACH and LOWER_TO_DATUM deliberately remain UNQUALIFIED:
    insertion demands narrowphase contacts and real fixture/pivot geometry.
    """
    if geometry is None:
        geometry=geometry_snapshot(Path(__file__).resolve().parents[1]/'source_v27')
    source=vector(SOURCE_WORLD);target=vector(TARGET_WORLD)
    off=vector(GRASP_WORLD_OFFSET)
    h=vector([0.,LIFT_M,0.])
    lane_x=float(geometry['corridor_lane_x'])
    # The corridor is derived from actual V27 STL bounds, never a guessed x.
    lane_high=vector([lane_x,source[1]+LIFT_M,source[2]])
    cross_high=vector([lane_x,source[1]+LIFT_M,target[2]])
    seat_high=target+h
    start_tool=source+off+vector([0.,.075,0.])
    tool_grasp=source+off
    # (phase, time, tcp_begin, tcp_end, cargo_mode, proxy_jaw, clearance_class)
    stages=[
      ('REGISTER',.55,start_tool,start_tool,'SOURCE',False,'STRICT_TRANSIT'),
      ('APPROACH',6.25,start_tool,tool_grasp,'SOURCE',False,'STRICT_TRANSIT'),
      ('GRASP_MOCK',.6,tool_grasp,tool_grasp,'SOURCE',True,'STRICT_TRANSIT'),
      ('VERTICAL_LIFT_210MM',18.0,tool_grasp,source+h+off,'ATTACH',True,'STRICT_TRANSIT'),
      ('MOVE_OUTSIDE_REAR_WHEEL',3.25,source+h+off,lane_high+off,'ATTACH',True,'STRICT_TRANSIT'),
      ('CROSS_BETWEEN_TWO_WHEELS',3.80,lane_high+off,cross_high+off,'ATTACH',True,'STRICT_TRANSIT'),
      ('HOLD_HIGH_VERIFY_CORRIDOR',.65,cross_high+off,cross_high+off,'ATTACH',True,'STRICT_TRANSIT'),
      ('FINAL_MATE_APPROACH_MOCK',3.20,cross_high+off,seat_high+off,'ATTACH',True,'UNQUALIFIED_MATING'),
      ('LOWER_TO_DATUM_MOCK',18.0,seat_high+off,target+off,'ATTACH',True,'UNQUALIFIED_MATING'),
      ('VERIFY_HOLD_MOCK',.55,target+off,target+off,'SEATED',True,'UNQUALIFIED_MATING'),
      ('RELEASE_MOCK',.6,target+off,target+off,'SEATED',False,'UNQUALIFIED_MATING'),
      ('RETRACT_MOCK',9.00,target+off,target+off+vector([0.,.105,0.]),'SEATED',False,'UNQUALIFIED_MATING'),
      ('DONE_REVIEW',1.1,target+off+vector([0.,.105,0.]),target+off+vector([0.,.105,0.]),'SEATED',False,'UNQUALIFIED_MATING'),
    ]
    rows=[];t=0.;idx=0
    for phase,dur,start,end,mode,closed,clearance_class in stages:
        count=max(2,int(round(dur*FPS)))
        for k in range(count):
            u=k/(count-1)
            tcp=start+(end-start)*smooth(u)
            cargo={'SOURCE':source,'ATTACH':tcp-off,'SEATED':target}[mode]
            rows.append({'index':idx,'time_s':round(t,6),'phase':phase,
                         'tcp_target':tcp.copy(),'g23_world':cargo.copy(),
                         'object_state':mode,'jaw_closed_mock':closed,
                         'clearance_class':clearance_class})
            idx+=1;t+=dur/count
    return rows

def analytic_seed(target_world):
    """Analytic planar 2R + wrist orientation + prismatic J3 for historical cell.

    Tool direction is held fixed at PHI; subtract its 0.3 m wrist extension
    before 2-link IK. This differs from treating the entire forearm as a single
    rotating segment, which would be kinematically incorrect for a 4DOF SCARA.
    """
    p=vector(target_world)
    local_x=p[0]-ROBOT_BASE_WORLD[0]
    local_y=ROBOT_BASE_WORLD[2]-p[2] # +localY -> -worldZ under R_x(-90)
    wrist_xy=np.array([local_x-L3*math.cos(PHI), local_y-L3*math.sin(PHI)])
    d2=float(wrist_xy @ wrist_xy)
    cos_q2=(d2-L1*L1-L2*L2)/(2.*L1*L2)
    if cos_q2 < -1.-1e-8 or cos_q2 > 1.+1e-8:
        raise ValueError('IK_UNREACHABLE_POSITION_ON_SOURCE_V27_ROBOT')
    q2=math.acos(max(-1.,min(1.,cos_q2)))
    q1=math.atan2(wrist_xy[1],wrist_xy[0])-math.atan2(L2*math.sin(q2),L1+L2*math.cos(q2))
    q4=PHI-q1-q2
    q3=p[1]-ROBOT_BASE_WORLD[1]
    return np.array([q1,q3,q2,q4],dtype=float)


def preflight_geometry():
    geo=geometry_snapshot(Path(__file__).resolve().parents[1]/'source_v27')
    rows=target_sequence(geo);qlist=[]
    for r in rows:
        q=analytic_seed(r['tcp_target'])
        if not (abs(q[0])<=2.61799 and -.04<=q[1]<=.24 and abs(q[2])<=1.74533 and abs(q[3])<=2.0944):
            raise ValueError(f'ANALYTIC_IK_OVER_JOINT_LIMIT_{r["phase"]}_{r["index"]}:{q.tolist()}')
        qlist.append(q)
    qs=np.array(qlist)
    times=np.array([r['time_s'] for r in rows])
    vel=np.diff(qs,axis=0)/np.diff(times)[:,None]
    v_abs=np.max(np.abs(vel),axis=0)
    # The 25 mm/s J3 threshold comes from the earlier frozen research limit,
    # not a manufacturer certified motor/controller maximum.
    if float(v_abs[1])>.025+1e-6:
        raise ValueError(f'PROVISIONAL_J3_VELOCITY_EXCEEDED: {v_abs[1]:.6f}m/s')
    wheel_clearance=audit_wheel_clearance(rows,geo)
    return {'number_frames':len(rows),'total_time_s':float(rows[-1]['time_s']),
            'stage_count':len(set(x['phase'] for x in rows)),
            'stage_names':list(dict.fromkeys(x['phase'] for x in rows)),
            'q_min':dict(zip(JOINTS,qs.min(0).tolist())),
            'q_max':dict(zip(JOINTS,qs.max(0).tolist())),
            'max_analytic_joint_velocity_abs':dict(zip(JOINTS,v_abs.tolist())),
            'J3_25mm_per_s_provisional_research_check_pass':True,
            'interpolation':'QUINTIC_MINIMUM_JERK_ZERO_ENDPOINT_V_A',
            'source_pose_m':list(SOURCE_WORLD),'assembled_CAD_reference_pose_m':list(TARGET_WORLD),
            'geometry_clearance_audit':{k:v for k,v in wheel_clearance.items() if k!='per_frame'},
            'physical_clearance_feasibility':public_geometry_snapshot(geo),
            'real_software_teacher_episodes':0,'physical_grasp_validated':False,
            'full_cycle_collision_free_certified':False}

def named_id(mujoco,model,obj,name):
    ret=int(mujoco.mj_name2id(model,obj,name))
    if ret<0:raise ValueError('MISSING_SCENE_REFERENCE_'+name)
    return ret


def prepare_ids(mujoco,model):
    J={}
    for nm in JOINTS:
        j=named_id(mujoco,model,mujoco.mjtObj.mjOBJ_JOINT,nm)
        J[nm]={'joint_id':j,'qadr':int(model.jnt_qposadr[j]),'dofadr':int(model.jnt_dofadr[j]),
               'range':tuple(float(v) for v in model.jnt_range[j])}
    if model.njnt!=4 or model.nq!=4 or model.nv!=4:
        raise ValueError(f'EXPECTED_ORIGINAL_4_DOF_ACTUATION_{model.njnt}_{model.nq}_{model.nv}')
    if model.nmocap!=3:
        raise ValueError(f'EXPECTED_3_ORIGINAL_MOCAP_MOTO_PARTS_{model.nmocap}')
    for b in AGV_STANDS+FIXTURES+WHEEL_NAMES:
        named_id(mujoco,model,mujoco.mjtObj.mjOBJ_BODY,b)
    site_id=named_id(mujoco,model,mujoco.mjtObj.mjOBJ_SITE,TCP_SITE)
    gid=named_id(mujoco,model,mujoco.mjtObj.mjOBJ_BODY,G23_NAME)
    mid=int(model.body_mocapid[gid]);assert mid>=0
    jaws=tuple(named_id(mujoco,model,mujoco.mjtObj.mjOBJ_SITE,'v51_mock_jaw_'+side) for side in ('left','right'))
    return {'joints':J,'tcp':site_id,'g23_mocap':mid,'jaws':jaws}


def set_qpos(mujoco,model,data,ids,q):
    for nm,val in zip(JOINTS,q):
        j=ids['joints'][nm]
        low,high=j['range']
        if not low-1e-7<=float(val)<=high+1e-7:raise ValueError('JOINT_LIMIT_'+nm)
        data.qpos[j['qadr']]=float(val)
    data.qvel[:]=0.
    mujoco.mj_forward(model,data)


def solve_ik(mujoco,model,data,ids,p,itermax=14):
    q=analytic_seed(p)
    # pin exact J1 + J2 + J4 wrist heading constraint; refine contact-free FK.
    j1=ids['joints']['R1__J1'];j2=ids['joints']['R1__J2'];j4=ids['joints']['R1__J4']
    for k in range(itermax):
        set_qpos(mujoco,model,data,ids,q)
        delta=vector(p)-data.site_xpos[ids['tcp']]
        if np.linalg.norm(delta) < 2.5e-4:return q,float(np.linalg.norm(delta)),k+1
        jp=np.zeros((3,model.nv),dtype=float);jr=np.zeros((3,model.nv),dtype=float)
        mujoco.mj_jacSite(model,data,jp,jr,ids['tcp'])
        # target horizontal X/Z, with constraint dq4=-dq1-dq2
        A=np.column_stack([
            jp[[0,2],j1['dofadr']]-jp[[0,2],j4['dofadr']],
            jp[[0,2],j2['dofadr']]-jp[[0,2],j4['dofadr']]
        ])
        err=delta[[0,2]]
        correction=np.linalg.solve(A.T@A+np.eye(2)*1e-6,A.T@err)
        correction=np.clip(correction,-.12,.12)
        q[0]+=correction[0];q[2]+=correction[1];q[3]=PHI-q[0]-q[2]
        q[1]+=float(delta[1])
    set_qpos(mujoco,model,data,ids,q)
    err=float(np.linalg.norm(vector(p)-data.site_xpos[ids['tcp']]))
    if err>8e-4:raise ValueError(f'IK_FK_MISMATCH_{err:.6f}m_{p}')
    return q,err,itermax


def validate_native_model(mujoco,model,data,ids):
    # All original AGV/stand bodies must be present at original source names.
    names={mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_JOINT,j) for j in range(model.njnt)}
    assert names==set(JOINTS),'ORIGINAL_JOINT_NAMES_CHANGED'
    assert model.nmesh==10,'EXPECTED_NINE_SOURCE_MESHES_PLUS_G29_FRAME_REF'
    # G23 & AGV wheel reference geometries MUST remain contact-disabled.
    for label in ['display_G23_gapxe_1','display_G08_banhxe_1',
                  'display_G56_banhtruoc_SEPARATE_FROM_FRONT_STEERING']:
        k=named_id(mujoco,model,mujoco.mjtObj.mjOBJ_GEOM,label)
        assert model.geom_contype[k]==0 and model.geom_conaffinity[k]==0,'PREVIEW_CONTACT_ENABLED'
    rows=target_sequence()
    worst=0.;qmin=np.ones(4)*100.;qmax=np.ones(4)*-100.
    for row in rows:
        q,err,n=solve_ik(mujoco,model,data,ids,row['tcp_target'])
        worst=max(worst,err);qmin=np.minimum(qmin,q);qmax=np.maximum(qmax,q)
        row['joint_positions']=q.copy();row['tcp_fk_error_m']=err
    if worst>.0008:raise ValueError('TCP_REPLAY_TOO_INACCURATE')
    return {'frames':len(rows),'max_tcp_fk_error_m':worst,
            'joint_min':dict(zip(JOINTS,qmin.tolist())),
            'joint_max':dict(zip(JOINTS,qmax.tolist())),
            'native_mujoco_model_compiled':True,
            'reference_wheels':list(WHEEL_NAMES), 'original_agvs':list(AGV_STANDS),
            'original_center_stands':list(FIXTURES),
            'gripper_force_physics':False,'m01_validated_loaded_insertion':False,
            'all_robot_motions_are_kinematic_forward_only':True},rows


def set_frame(mujoco,model,data,ids,row):
    set_qpos(mujoco,model,data,ids,row['joint_positions'])
    data.mocap_pos[ids['g23_mocap']]=row['g23_world']
    data.mocap_quat[ids['g23_mocap']]=[1.,0.,0.,0.]
    jaw=0.068 if row['jaw_closed_mock'] else 0.115
    for sign,k in zip((-1,+1),ids['jaws']):
        model.site_pos[k]=[0.,sign*jaw,-0.055]
        model.site_rgba[k]=[.20,.94,.32,.95] if row['jaw_closed_mock'] else [1.,.54,.16,.70]
    mujoco.mj_forward(model,data)


def write_trace(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f)
        w.writerow(['frame','t_s','phase','object_state','J1_rad','J3_m','J2_rad','J4_rad',
                    'tcp_target_x_m','tcp_target_y_m','tcp_target_z_m',
                    'G23_world_x_m','G23_world_y_m','G23_world_z_m',
                    'grip_closed_mock','tcp_fk_err_m','acceptance','clearance_class'])
        for row in rows:
            w.writerow([row['index'],row['time_s'],row['phase'],row['object_state'],
                *row['joint_positions'],*row['tcp_target'],*row['g23_world'],
                row['jaw_closed_mock'],row['tcp_fk_error_m'],
                'VISUAL_REVIEW_ONLY_NOT_TEACHER',row['clearance_class']])


def write_clearance_review_evidence(out,package):
    """Export researched CAD AABB clearance, including per-frame risk labels."""
    out=Path(out);package=Path(package)
    geo=geometry_snapshot(package/'source_v27')
    rows=target_sequence(geo)
    clearance=audit_wheel_clearance(rows,geo)
    public=public_geometry_snapshot(geo)
    report={
      'schema':'R1_V513_CAD_AABB_WHEEL_CORRIDOR_REVIEW_V1',
      'source_scene':'R1_V27_SCENE.xml',
      'source_module':'G23_gapxe_1.stl',
      'source_wheels':['G08_banhxe_1.stl','G56_banhtruoc_SEPARATE_FROM_FRONT_STEERING.stl'],
      'collision_method':'CAD_STL_AABB_CONSERVATIVE_ONLY',
      'geometry':public,
      'wheel_clearance_summary':{k:v for k,v in clearance.items() if k!='per_frame'},
      'frame_count':len(rows),
      'all_original_source_unchanged':True,
      'over_the_wheel_path_approved':False,
      'G23_assembly_contact_approved':False,
      'robot_vs_tool_versus_fixture_collision_approved':False,
      'hardware_commands':0,
    }
    (out/'R1_V513_CLEARANCE_AUDIT.json').write_text(
        json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    with (out/'R1_V513_WHEEL_CLEARANCE_FRAMES.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f)
        w.writerow(['frame','t_s','phase','clearance_class',
                    'G23_center_x_m','G23_center_y_m','G23_center_z_m',
                    'minimum_wheel_aabb_gap_m','risk'])
        for row,c in zip(rows,clearance['per_frame']):
            w.writerow([row['index'],row['time_s'],row['phase'],row['clearance_class'],
                        *row['g23_world'],round(c['min_wheel_aabb_gap_m'],6),
                        ('MATING_NOT_QUALIFIED' if row['clearance_class']=='UNQUALIFIED_MATING'
                         else 'AABB_TRANSIT_STANDOFF_CHECKED')])
    return report


def manifest_for_outputs(out):
    out=Path(out)
    rows={p.relative_to(out).as_posix():sha(p) for p in sorted(out.rglob('*'))
          if p.is_file() and p.name!='OUTPUT_SHA256.json'}
    (out/'OUTPUT_SHA256.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')



def assert_ascii_native_stage(scene_path):
    """Check MuJoCo's Windows XML parser sees an ASCII-only real filename.

    r1_runs can be inside a Windows project path containing non-ASCII text; native XML must
    not be compiled from that non-ASCII path in MuJoCo 3.15.0 on Windows.
    """
    xml_path=Path(scene_path).resolve()
    if not str(xml_path).isascii():
        raise ValueError('NATIVE_SCENE_PATH_NOT_ASCII: '+str(xml_path))
    if not xml_path.is_file():
        raise ValueError('NATIVE_XML_FILE_NOT_FOUND: '+str(xml_path))
    ET.parse(xml_path)  # Detect malformed XML before calling native MuJoCo.
    required_files=sorted(xml_path.parent.glob('*.stl'))
    if len(required_files)!=10:
        raise ValueError(f'NATIVE_STAGE_EXPECTED_10_STL_HAVE_{len(required_files)}')
    if not all(f.is_file() and f.stat().st_size>80 for f in required_files):
        raise ValueError('NATIVE_STAGE_EMPTY_OR_MISSING_MESH')
    return {'ascii_native_xml_path':str(xml_path),
            'ascii_native_path_verified':True,
            'staged_xml_sha256':sha(xml_path),
            'stl_files':[{ 'file':q.name,'sha256':sha(q)} for q in required_files]}


def create_ascii_stage_dir():
    """Caller owns lifetime. The requested evidence dir is NEVER the compile dir.

    Windows TEMP is ASCII in the user's deployment; fail closed if it is not.
    No fake success, no source modification, and no external drive mappings.
    """
    root=Path(tempfile.gettempdir()).resolve()
    if not str(root).isascii():
        raise RuntimeError('WINDOWS_TEMP_PATH_CONTAINS_NON_ASCII: '+str(root)
          +'; set TEMP and TMP to an existing writable ASCII-only folder, restart terminal')
    return tempfile.TemporaryDirectory(prefix='r1v512_ascii_mjcf_',dir=str(root))


def stage_for_native(package, out, ascii_root):
    """Build under ASCII temp, preserve a matching audited evidence copy."""
    ascii_scene_root=Path(ascii_root)/'scene'
    scene=stage_scene(package,ascii_scene_root)
    audit=assert_ascii_native_stage(scene['scene_xml'])
    copy_out=out/'scene'
    if copy_out.exists():
        raise ValueError('REFUSE_OVERWRITE_EXISTING_SCENE')
    shutil.copytree(ascii_scene_root,copy_out)
    copied_scene=copy_out/Path(scene['scene_xml']).name
    if sha(copied_scene)!=audit['staged_xml_sha256']:
        raise RuntimeError('EVIDENCE_SCENE_COPY_HASH_MISMATCH')
    for stl in audit['stl_files']:
        if sha(copy_out/stl['file'])!=stl['sha256']:
            raise RuntimeError('EVIDENCE_STL_COPY_HASH_MISMATCH: '+stl['file'])
    scene['evidence_xml_path']=str(copied_scene)
    return scene,audit

class NativeCompileError(RuntimeError):
    def __init__(self, message, attempts):
        super().__init__(message)
        self.attempts=attempts


def compile_native_model(mujoco, xml_path, stl_audit):
    """Try ASCII-path native load; fallback to bytes-only asset loading.

    Return (compiled MjModel, load_attempts); never report success on failure.
    """
    xml_path=Path(xml_path)
    assert_ascii_native_stage(xml_path)
    attempts=[]
    try:
        model=mujoco.MjModel.from_xml_path(str(xml_path))
        attempts.append({'method':'FROM_ASCII_XML_PATH','status':'PASS'})
    except Exception as native_exc:
        attempts.append({'method':'FROM_ASCII_XML_PATH','status':'FAIL',
                         'error':str(native_exc)})
        mesh_assets={f['file']:(xml_path.parent/f['file']).read_bytes()
                     for f in stl_audit['stl_files']}
        xml_content=xml_path.read_text(encoding='utf-8')
        try:
            model=mujoco.MjModel.from_xml_string(xml_content,assets=mesh_assets)
            attempts.append({'method':'FROM_XML_STRING_WITH_BINARY_ASSETS','status':'PASS'})
        except Exception as fallback_exc:
            attempts.append({'method':'FROM_XML_STRING_WITH_BINARY_ASSETS',
                             'status':'FAIL','error':str(fallback_exc)})
            raise NativeCompileError('NATIVE_COMPILE_FAILED_BOTH_ASCII_AND_IN_MEMORY: '
                               +str(native_exc)+' | FALLBACK: '+str(fallback_exc),attempts) from fallback_exc
    return model,attempts


def run(argv=None):
    ap=argparse.ArgumentParser(description='Restore historical V27 AGVs + center stands and animate M01 G23 on native MuJoCo')
    ap.add_argument('--package',required=True)
    ap.add_argument('--out',required=True)
    ap.add_argument('--mode',choices=['static','verify','auto'],default='auto')
    ap.add_argument('--speed',type=float,default=1.)
    ap.add_argument('--loop',action='store_true')
    args=ap.parse_args(argv)
    package=Path(args.package).resolve();out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)
    result={
      'schema':'R1_V513_WHEEL_CORRIDOR_LIFT_REVIEW_V1',
      'timestamp_utc':datetime.now(timezone.utc).isoformat(),
      'status':'BLOCKED', 'selected_original_stage':'01_M01_GAPXE_REFERENCE',
      'source_v27_verified':False,'mujoco_compiled_new_scene':False,
      'V48_FROZEN_UNCHANGED':True,'production_hardware_approved':False,
      'teacher_M01_approved':False,'BC_or_SAC_train_approved':False,
      'g23_payload_physics_validated':False,'g23_loaded_insertion_validated':False,
      'human_verified_fixture_alignment':False,'motor_commands':0,
      'scene_scope':'NATIVE_MUJOCO_KINEMATIC_LIFT_AND_WHEEL_CORRIDOR_REVIEW_NOT_REAL_GRASP_SIM',
      'collision_free_loaded_assembly_approved':False,
    }
    try:
        ensure_source(package)
        preflight=preflight_geometry()
        result['preflight_geometry']=preflight
        result['V513_clearance_review']=write_clearance_review_evidence(out,package)['wheel_clearance_summary']
        with create_ascii_stage_dir() as ascii_temp:
            scene,native_path_audit=stage_for_native(package,out,ascii_temp)
            # Record the persistent evidence scene, not a deleted temp path.
            result['restored_source']={**scene,
                'scene_xml': scene['evidence_xml_path'],
                'ascii_temp_compile_path_ephemeral':True}
            result['source_v27_verified']=True
            result['native_compile_path_audit']=native_path_audit
            result['native_scene_evidence_sha256_matches_ascii_staging']=True
            result['native_loader_path_method']='ASCII_TEMP_ABSOLUTE_PATH'
            if args.mode=='static':
                result['status']='SOURCE_AND_XML_RESTORED_NATIVE_COMPILE_PENDING'
            else:
                import mujoco
                result['native_mujoco_version']=str(mujoco.__version__)
                # V5.1.1 failed from a project path containing `Máy tính`.
                # Here the MuJoCo C++ XML parser receives only an ASCII path.
                model,attempts=compile_native_model(mujoco,scene['scene_xml'],native_path_audit)
                result['native_loader_attempts']=attempts
                result['mujoco_compiled_new_scene']=True
                data=mujoco.MjData(model)
                ids=prepare_ids(mujoco,model)
                audits,rows=validate_native_model(mujoco,model,data,ids)
                write_trace(out/'R1_V51_G23_AUTOPLAY_TRACE.csv',rows)
                result['native_trajectory_validation']=audits
                result['status']='NATIVE_V27_LIFT_DETOUR_PREMATE_AABB_PASS_SEATING_UNQUALIFIED'
                result['mating_contact_approved']=False
                result['strict_transit_cad_aabb_checked']=True
                if args.mode=='auto':
                    import mujoco.viewer
                    if not math.isfinite(args.speed) or not .1<=args.speed<=5:
                        raise ValueError('INVALID_PLAYBACK_SPEED')
                    # Single MuJoCo window; no Tk GUI or fake actuator interface.
                    set_frame(mujoco,model,data,ids,rows[0]);result['auto_viewer_opened']=False
                    viewer=mujoco.viewer.launch_passive(model,data,show_left_ui=False,show_right_ui=False)
                    try:
                        with viewer.lock():
                            viewer.cam.lookat[:]=[-.05,-.15,.35]
                            viewer.cam.distance=3.15
                            viewer.cam.azimuth=105.
                            viewer.cam.elevation=-18.
                            viewer.opt.geomgroup[1]=1
                            viewer.opt.geomgroup[4]=1
                            viewer.opt.geomgroup[5]=0  # original red visual reference BOXes hidden
                            viewer.opt.sitegroup[4]=1
                            try:
                                viewer.opt.flags[mujoco.mjtVisFlag.mjVIS_SITE]=1
                            except Exception:pass
                        result['auto_viewer_opened']=True
                        start=time.perf_counter();times=[r['time_s'] for r in rows]
                        duration=times[-1];lastphase=None;max_seen_frame=-1;full_cycles=0
                        while viewer.is_running():
                            elapsed=(time.perf_counter()-start)*args.speed
                            if args.loop:
                                t=elapsed % max(1e-9,duration)
                            else:
                                t=min(elapsed,duration)
                            idx=max(0,min(len(rows)-1,bisect.bisect_right(times,t)-1))
                            max_seen_frame=max(max_seen_frame,idx)
                            full_cycles=max(full_cycles,int(elapsed//max(1e-9,duration)))
                            row=rows[idx]
                            if row['phase']!=lastphase:
                                print(f'[MuJoCo {t:6.2f}s] {row["phase"]} | G23 {row["object_state"]}; {row["clearance_class"]}; visual-only',flush=True)
                                lastphase=row['phase']
                            set_frame(mujoco,model,data,ids,row)
                            viewer.sync()
                            time.sleep(.02)
                        result['auto_viewer_closed']=True
                        result['full_cycle_visually_elapsed_in_viewer']=bool(max_seen_frame>=len(rows)-1 or full_cycles>=1)
                        result['operator_physical_assembly_signoff']=False
                    finally:
                        viewer.close()
        print('STATUS:',result['status'])
    except Exception as exc:
        if isinstance(exc,NativeCompileError):
            result['native_loader_attempts']=exc.attempts
        result['error_type']=type(exc).__name__
        result['error_message']=str(exc)
        print(f'BLOCKED: {type(exc).__name__}: {exc}',file=sys.stderr)
    finally:
        (out/'R1_V51_GATE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=lambda v:v.tolist() if isinstance(v,np.ndarray) else str(v))+'\n',encoding='utf-8')
        manifest_for_outputs(out)
        print('Evidence:',out/'R1_V51_GATE.json')
    return 0 if result['status']!='BLOCKED' else 2

if __name__=='__main__':sys.exit(run())
