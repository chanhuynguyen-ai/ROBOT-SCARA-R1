# R1 V5.1.3 — START HERE

Đọc **[README_V513_VI.md](README_V513_VI.md)** trước khi chạy.

Đây là nhánh **MuJoCo xem logic nâng / tránh bánh bằng CAD V27**; **không sửa frozen software baseline V4.8**. Phần nâng/vận chuyển trước vùng lắp đã được kiểm tra CAD AABB; phần seat cuối **không được chứng nhận contact/va chạm**. Chạy `RUN_WINDOWS.ps1` trong PowerShell từ ZIP mới.
