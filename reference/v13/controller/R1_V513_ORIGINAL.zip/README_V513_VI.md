# R1 V5.1.3 — MuJoCo: ẩn BOX đỏ, nâng G23 và đi vòng vùng bánh xe

**Ngày:** 19/10/2026  
**Nguồn được giữ nguyên:** scene `R1_V27_SCENE.xml`, 9 STL gốc V27 + G29 visual, 2 AGV, 2 bánh G08/G56, 2 gá P2/P3, vị trí cuối `G23_gapxe_1`.  
**V4.8 FROZEN không bị sửa.**  
**Phạm vi:** MuJoCo native review động học/logic, không phải Teacher M01 hoặc xác nhận lắp thật.

## 1. Những thay đổi bạn sẽ nhìn thấy

1. **Không còn mảng đỏ trong cánh tay**: 6 BOX tham chiếu tên `R1__c_*` / `R1__R1V22_SOURCE_WORLD_001` được chuyển sang `group=5`, `rgba alpha=0` *chỉ trong MJCF staged*. Mesh CAD của tay máy không bị xóa. Các tín hiệu đỏ khác trên gá P2 là cờ thiếu adapter lịch sử, không phải hình học robot.
2. **Không còn chuyển G23 sát bánh theo đường cũ.** Thao tác mới nâng G23 210 mm theo trục **Y thế giới** của scene V27, chạy ra ngoài vùng bánh sau, rồi chuyển ngang qua **hành lang trống theo X** giữa hai bánh. Từ đó robot tiếp cận và hạ G23 về vị trí đặt lịch sử.
3. **Không có GUI Tk:** MuJoCo Viewer tự chạy, `-Loop` tùy chọn. Bấm chuột để xoay/zoom.
4. **Tái định thời:** sử dụng nội suy quintic (zero velocity/acceleration tại điểm đầu-cuối của từng đoạn), theo giới hạn J3 nghiên cứu tạm 25 mm/s. Khoảng 65,53 s/một chu trình ở `-Speed 1.0`, hoặc khoảng 32,8 s ở `-Speed 2` (chỉ là tốc độ phát viewer).

## 2. Tại sao không nâng thẳng qua bánh?

Khi giữ offset TCP→G23 **+150 mm theo Y** từ V5.1.2, vùng bao CAD kiểm tra được:

| Hạng mục | Kết quả |
|---|---:|
| J3 cho phép theo V27 | −40 → +240 mm |
| J3 tối đa trong quỹ đạo mới | ≈220,68 mm |
| Nâng G23 so với feeder | **210 mm** |
| Y cao nhất của bánh G08 | ≈ +32,09 mm |
| Y đáy thấp nhất của G23 (local) | −88,19 mm |
| Khoảng đệm hình học nghiên cứu | 25 mm |
| **J3 cần nếu nhấc G23 hoàn toàn qua ĐỈNH bánh** | **≈399,64 mm** |
| **Thiếu hành trình J3 so với giới hạn hiện tại** | **≈159,64 mm** |

Bởi vậy, tăng J3 lên 400 mm trong mô phỏng mà chưa có bản vẽ/actuator thật sẽ gây hiểu lầm. V5.1.3 dùng **đường đi vòng có khoảng hở AABB kiểm được** trước bước lắp, còn bước tiếp xúc lắp G23 với bánh/gá được đánh dấu rõ `UNQUALIFIED_MATING`.

## 3. Mốc số liệu kiểm tra offline

- **13 pha / 2.622 frame**, khoảng **65,525 s**; 40 FPS dữ liệu.
- Khoảng hở bảo thủ nhỏ nhất giữa vùng bao AABB G23 và **hai bánh CAD** trong các pha vận chuyển **trước tiếp cận lắp**: **36,38 mm** (ngưỡng 25 mm).
- Vị trí X tâm hành lang được suy ra từ 3 STL: **0,066358 m** (không đoán tay).
- Vận tốc lớn nhất theo trục J3 trong quỹ đạo giải tích: **≈0,02259 m/s**, dưới ngưỡng nghiên cứu 0,025 m/s.
- Tư thế đặt G23 giữ nguyên pose tham chiếu V27: **(−0,302850; −0,243680; 0) m**.
- **Không kết luận toàn bộ quỹ đạo không va chạm**: giao thoa AABB trong pha mate/seat là vùng cần CAD gripper, pivot, contact và tolerance để kiểm chứng narrowphase. Mô hình chưa có lực giữ, không có `mj_step`, không có servo/HIL, không thể huấn luyện Teacher M01.

## 4. Chạy trên Windows (copy toàn bộ)

Tải ZIP `R1_V513_CLEARANCE_LIFT_DETOUR_20261019.zip` vào Downloads:

```powershell
$ErrorActionPreference = 'Stop'
$project = 'C:\Máy tính\Arm_robot\scara42_starter'
$zip = Get-ChildItem -LiteralPath (Join-Path $env:USERPROFILE 'Downloads') -File `
    -Filter 'R1_V513_CLEARANCE_LIFT_DETOUR_20261019*.zip' |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($null -eq $zip) { throw 'Download ZIP V5.1.3 vao Downloads truoc' }

$dest = Join-Path $env:TEMP 'R1_V513_CLEARANCE_LIFT_DETOUR_20261019'
Expand-Archive -LiteralPath $zip.FullName -DestinationPath $dest -Force

$runner = Join-Path $dest 'RUN_WINDOWS.ps1'
if (!(Test-Path -LiteralPath $runner -PathType Leaf)) {
    throw 'Khong tim thay runner o root cua ZIP. Kiem tra noi dung ZIP.'
}

# 1. Verify native MuJoCo + FK/IK, khong mo viewer
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runner -ProjectRoot $project -Mode verify
if ($LASTEXITCODE -ne 0) { throw 'V5.1.3 native gate chua dat; gui ZIP evidence' }

# 2. Mo native MuJoCo viewer, tu dong phat lai toan bo chuoi
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runner -ProjectRoot $project -Mode auto -Speed 1.0 -Loop
if ($LASTEXITCODE -ne 0) { throw 'V5.1.3 autoplay failed; gui ZIP evidence' }
```

Nếu muốn duyệt nhanh, thay `-Speed 1.0` bằng `-Speed 2.0`. Đây là **tăng tốc phát lại thị giác**, không được dùng để kết luận actuator phù hợp.

## 5. Evidence trong `r1_runs`

Sau khi chạy sẽ sinh thư mục `r1_runs\R1_V513_LIFT_WHEEL_DETOUR_<timestamp>` và ZIP `R1_V513_<timestamp>_EVIDENCE_ONLY.zip`.

Các tệp chính:
- `R1_V51_GATE.json`: native compiler, FK/IK, số liệu và trạng thái.
- `R1_V51_G23_AUTOPLAY_TRACE.csv`: joint pose cho từng frame sau native verify.
- `R1_V513_CLEARANCE_AUDIT.json`: AABB source & bánh, J3 stroke overhead gate và số liệu worst-case.
- `R1_V513_WHEEL_CLEARANCE_FRAMES.csv`: 2.622 frame với phân loại `STRICT_TRANSIT` / `UNQUALIFIED_MATING`.
- `scene\R1_V51_RESTORED_AGV_P2_P3_G23_AUTO.xml`: MJCF staged và 10 STL bảo quản.

Bạn có thể gửi ZIP evidence để đối chiếu. Gửi ảnh MuJoCo ở 3 thời điểm: **`VERTICAL_LIFT_210MM`, `CROSS_BETWEEN_TWO_WHEELS`, `LOWER_TO_DATUM_MOCK`**.

## 6. Cơ khí còn cần xác nhận để xóa BLOCKED vùng seat

1. `T_flange^TCP`, CAD EOAT thật, điểm kẹp / lực giữ / độ võng G23.
2. Vị trí/hệ trục feeder, 2 gá P2/P3 và trục wheel axle/pivot theo bản vẽ lắp chính thức.
3. CAD / collision mesh chi tiết của G23, bánh, khung, gripper và các tiếp xúc có chủ đích.
4. Dung sai lắp, vùng cấm, kế hoạch insertion (trục/độ sâu/giới hạn lực), sensor xác nhận fixture & tool.
5. Khối lượng, COM, inertia, torque-speed servo và giới hạn J3 thật để quyết định nâng qua bánh hoặc dùng hành lang đi vòng.

**Quyết định kỹ thuật:** V5.1.3 chỉ đủ điều kiện review **hành lang vận chuyển G23 trước khi lắp**. Nếu bắt buộc nâng G23 hoàn toàn lên qua bánh theo đường thẳng, cơ khí phải thay đổi stroke J3 / mounting / TCP offset hoặc phê duyệt một bố trí khác. Không nâng khống giới hạn robot.
