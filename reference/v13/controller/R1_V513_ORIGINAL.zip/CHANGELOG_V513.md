# V5.1.3 change log

- Hide six red translucent, non-contact, massless robot BOX proxies from display (no original CAD deletion).
- Restore original V27 AGV, wheel, P2/P3, G23 geometry and exact final G23 datum.
- Introduce STL-based, 25 mm-standoff wheel corridor computed from source geometry (X world≈0.066358 m).
- Change choreography from 120 mm short lift to 210 mm J3-constrained lift, safe nonmating X-lane detour, and separate explicitly UNQUALIFIED mating descent.
- Re-time to quintic minimum-jerk with provisional 0.025 m/s J3 speed cap.
- Export AABB clearance audit in JSON/CSV for every frame; fail closed if blocked in non-mating phases.
- Retain Windows native ASCII-path MuJoCo compile with in-memory STL fallback.
- No change to frozen V4.8 or hash-pinned original V27 sources. No physical safety/Teacher approvals.
