param(
    [Parameter(Mandatory=$true)][string]$ProjectRoot,
    [ValidateSet('static','verify','auto')][string]$Mode = 'auto',
    [double]$Speed = 1.0,
    [switch]$Loop
)
$ErrorActionPreference = 'Stop'

# The package ZIP has RUN_WINDOWS.ps1 at the archive root. $PSScriptRoot also
# works if a download tool puts it inside an extra folder.
$package = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($package)) { throw 'Package root cannot be resolved' }
$required = @(
    'src\verify_release.py',
    'src\r1_v51_autoplay.py',
    'src\r1_v51_scene.py',
    'source_v27\R1_V27_SCENE.xml',
    'PACKAGE_SHA256_MANIFEST.json'
)
foreach ($relative in $required) {
    $path = Join-Path $package $relative
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing release file $relative. Re-extract the entire ZIP: $package"
    }
}
if (!(Test-Path -LiteralPath $ProjectRoot -PathType Container)) {
    throw "Project root does not exist: $ProjectRoot"
}
$python = Join-Path $ProjectRoot '.venv\Scripts\python.exe'
if (!(Test-Path -LiteralPath $python -PathType Leaf)) {
    throw "Missing project Python virtual environment: $python"
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$output = Join-Path $ProjectRoot "r1_runs\R1_V513_LIFT_WHEEL_DETOUR_$stamp"
New-Item -ItemType Directory -Path $output -Force | Out-Null

Write-Host 'R1 V5.1.3 MuJoCo real V27 lift and wheel-detour review'
Write-Host "Runner: $PSCommandPath"
Write-Host "Package: $package"
Write-Host "Project: $ProjectRoot"
Write-Host "Mode: $Mode"
Write-Host "Output: $output"
Write-Host 'Native compile: ASCII-only temporary scene, with in-memory assets fallback.'

& $python (Join-Path $package 'src\verify_release.py') $package
if ($LASTEXITCODE -ne 0) {
    throw 'Release SHA256 verification failed; do not start the viewer.'
}

$cmdArgs = @(
    (Join-Path $package 'src\r1_v51_autoplay.py'),
    '--package', $package,
    '--out', $output,
    '--mode', $Mode,
    '--speed', [string]::Format([cultureinfo]::InvariantCulture, '{0}', $Speed)
)
if ($Loop) { $cmdArgs += '--loop' }
& $python @cmdArgs
$exitCode = $LASTEXITCODE
# Always export a compact evidence ZIP, including diagnostic JSON on failure.
$evidenceZip = Join-Path $ProjectRoot "r1_runs\R1_V513_${stamp}_EVIDENCE_ONLY.zip"
$evidenceItems = @(
    (Join-Path $output 'R1_V51_GATE.json'),
    (Join-Path $output 'OUTPUT_SHA256.json'),
    (Join-Path $output 'R1_V51_G23_AUTOPLAY_TRACE.csv'),
    (Join-Path $output 'R1_V513_CLEARANCE_AUDIT.json'),
    (Join-Path $output 'R1_V513_WHEEL_CLEARANCE_FRAMES.csv')
) | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }
if ($evidenceItems.Count -gt 0) {
    Compress-Archive -LiteralPath $evidenceItems -DestinationPath $evidenceZip -Force
    Write-Host "Evidence ZIP: $evidenceZip"
}
Write-Host "Gate JSON: $(Join-Path $output 'R1_V51_GATE.json')"
Write-Host "Evidence MuJoCo XML: $(Join-Path $output 'scene\R1_V51_RESTORED_AGV_P2_P3_G23_AUTO.xml')"
Write-Host 'Native load method: read R1_V51_GATE.json/native_loader_attempts.'
if ($exitCode -ne 0) {
    Write-Host 'BLOCKED: Inspect R1_V51_GATE.json and share its error_message.'
}
exit $exitCode
